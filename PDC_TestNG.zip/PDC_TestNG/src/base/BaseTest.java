package base;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import junit.framework.TestCase;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class BaseTest extends TestCase {
    public String baseUrl = "https://dc-cert.hmhco.com/hmhstorefront/login";
    String driverPath = "D:\\Software\\chromedriver_win32\\chromedriver.exe";
    String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
    public static WebDriver driver; 
    public String expected = null;
    public String actual = null;
    
        @BeforeMethod(alwaysRun=true)
      public void launchBrowser() {
          System.out.println("launching Chrome"); 
          System.setProperty("webdriver.chrome.driver",driverPath);
          driver= new ChromeDriver();
          driver.get(baseUrl);
          driver.manage().window().maximize();
          driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
      }
           
      @AfterMethod(alwaysRun=true)
      public void takeScreenShotsAndLogout() throws IOException {
  		File srcfile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
  		FileUtils.copyFile(srcfile, new File("D:\\Libraries\\"+timeStamp+".PNG"));
  		 driver.findElement(By.linkText("Log Out")).click();
         driver.close();
  		  	}
         
     /*@AfterTest
      public void terminateBrowser(){
    	          driver.close();
      }*/
}