package pdc.pages;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.io.File;
import java.text.DateFormat;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import junit.framework.TestCase;
import pdc.pages.*;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ById;
import org.openqa.selenium.By.ByLinkText;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import com.thoughtworks.selenium.Selenium;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;
import com.thoughtworks.selenium.webdriven.commands.IsVisible;
import com.thoughtworks.selenium.webdriven.commands.WaitForPageToLoad;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import base.BaseTest;
import com.google.common.base.Function;
import com.google.common.base.Predicate;

	public class Login extends BaseTest {		
		protected String ufirstname ="Autouser"+UUID.randomUUID().toString().substring(0,3);
		protected String ulastname ="Autouser"+UUID.randomUUID().toString().substring(0,3);
		protected String mailid ="Autouser"+UUID.randomUUID().toString().substring(0,5)+"@mail.com";
		protected String password ="Password-1";
		WebDriverWait wait = new WebDriverWait(driver, 300);
		public String usernametxt = "patrick.o'riordan@hmhco.com";
		public String mulusernametxt = "hmhpdc17@yahoo.com";
		public String mulpwdtxt = "123Password";		
		public String pwdtxt = "dapassword";
		public String SchoolDrpDwn = "dapassword";
		public String sauname= "saadmin@school.com";
		public String sapwdtxt = "sapassword";
		public String tcuname= "teacher@school.com";
		public String tcpwdtxt = "teacherpassword";
		private boolean acceptNextAlert = true;
		@FindBy(id = "j_username")
		protected WebElement username;
	    
		@FindBy(id = "j_password")
		protected WebElement Password;
		
		@FindBy(id = "Role")
		protected WebElement role;
		
		@FindBy(xpath = "//form[@id='hmhCreateUserForm']/div[4]/div/div[2]/dl/span/dd/span/a")
		protected WebElement schooldrpdwn;
		
		@FindBy(id = "profile.firstName")
		protected WebElement firstname;
			
		@FindBy(id = "profile.lastName")
		protected WebElement lastname;
		
		@FindBy(id = "profile.email")
		protected WebElement email;
		
		@FindBy(id = "profile-password")
		protected WebElement pwd;
		
		@FindBy(id = "profile-confirm-password")
		protected WebElement cnfpwd;
		
		@FindBy(css = "input.createuserbtn.rc-user-btn")
		protected WebElement createuser;
		
		@FindBy(css = "a.recall-confirm")
		protected WebElement recallconfirm;
		
		@FindBy(name = "reissue")
		protected WebElement reissueconfirm;
		
		@FindBy(id = "Title")
		protected WebElement title;
		
		@FindBy(id = "filterSearchByStatus")
		protected WebElement filterSearchByStatus;
		
		@FindBy(id = "changeOrganisation")
		protected WebElement changeorg;
		
		@FindBy(id = "org_form")
		protected WebElement orgform;
		
		@FindBy(id = "createBundleBtn")
		protected WebElement createbundlecontinue;
		
		@FindBy(xpath = "//*[@id='hmhCreateUserForm']//p[2]")
		protected WebElement verifycreateduser;
		
		
		@FindBy(xpath = "//html/body/div[5]/div[4]/div/ul/li[2]/div/ul")
		protected WebElement dashboardverify;
		
		@FindBy(css = "p.cumuc1.firepath-matching-node")
		protected WebElement verifycreatedusermsg;
		
		@FindBy(css = "input.createBudleAdd")
		protected WebElement bundleproduct1;
		
		@FindBy(css = "span")
		protected WebElement homeverify;
		
		@FindBy(css = "input.delbtn")
		protected WebElement bundleproduct2;
		
		@FindBy(xpath = "//div[2]/input")
		protected WebElement Loginbutton;
		
		@FindBy(xpath = "//*[@id='content']/div[4]//a[1]")
		protected WebElement Licensesavailable;
		
		@FindBy(xpath = "//*[@id='content']//a[2]")
		protected WebElement Activebundles;
		
		@FindBy(xpath = "//*[@id='bndleSuccess']")
		protected WebElement bundlesuccess;
		
		@FindBy(xpath = "//input[2]")
		protected WebElement searchbutton;
				
		@FindBy(xpath = "//*[@id='content']//div[5]/div[1]")
		protected WebElement searchtable;
		
		@FindBy(id = "init")
		protected WebElement Schoolselect;
		
		@FindBy(id = "init_org")
		protected WebElement orgselect;
		
		@FindBy(xpath = "//*[@id='bundlerow3']//div[2]")
		protected WebElement packagecode;
		
		@FindBy(xpath = "//*[@id='content']/div/div/div[2]/div[2]/div[6]/label")
		protected WebElement downloadpage;
		
		@FindBy(linkText = "PRODUCTS AND LICENSES")
		protected WebElement PRODUCTSANDLICENSES;
		
		@FindBy(linkText = "exact:Forgotten your password?")
		protected WebElement forgotpassword;
		
		@FindBy(linkText = "I am a Student")
		protected WebElement studentlink;
		
		@FindBy(linkText = "MY DASHBOARD")
		protected WebElement dashboard;
		
		@FindBy(linkText = "BUNDLES")
		protected WebElement BUNDLES;
		
		@FindBy(linkText = "PACKAGES")
		protected WebElement Pakages;
		
		@FindBy(linkText = "SCHOOLS AND USERS")
		protected WebElement SCHOOLSANDUSERS;
		
		@FindBy(linkText = "TestSchool")
		protected WebElement schoolselect1;
		
		@FindBy(linkText = "Allocate Licenses")
		protected WebElement ALLOCATELICENSES;
		
		@FindBy(linkText = "Manage Licenses")
		protected WebElement MANAGELICENSES;
		
		@FindBy(linkText = "Create Users")
		protected WebElement CreateUsers;
		
		@FindBy(linkText = "Manage Users")
		protected WebElement Manageusers;
	
		@FindBy(linkText = "Allocation History")
		protected WebElement AllocationHistory;
		
		@FindBy(linkText = "Teacher Resources")
		protected WebElement TeacherResources;
		
		@FindBy(linkText = "Create Packages")
		protected WebElement CreatePackages;
		
		@FindBy(linkText = "eTextbooks")
		protected WebElement eTextbooks;
		
		@FindBy(linkText = "Create Bundles")
		protected WebElement createbundle;
		
		@FindBy(linkText = "Manage Bundles")
		protected WebElement Managebundles;
		
		@FindBy(linkText = "Manage Packages")
		protected WebElement Managepackages;
		
		@FindBy(linkText = "Package title")
		protected WebElement status;
		
		@FindBy(linkText = "Status")
		protected WebElement status1;
		
		@FindBy(name = "grade")
		protected WebElement gradeselect;
		
		@FindBy(id = "filterSearchByStatus")
		protected WebElement bundlestatus;
		
		@FindBy(id = "filterSearchByRole")
		protected WebElement userselect;
		
		@FindBy(name = "search")
		protected WebElement search;
		
		@FindBy(linkText = "Quantity allocated")
		protected WebElement Quantityallocated;
		
		@FindBy(linkText = "Total licenses")
		protected WebElement Totallicences;
		
		@FindBy(linkText = "Last")
		protected WebElement Lastpage;
		
		@FindBy(name = "status")
		protected WebElement statusselect;
		
		@FindBy(name = "licenses")
		protected WebElement licences;
		
		@FindBy(linkText = "First")
		protected WebElement firstPage;
		@FindBy(linkText = "Grade")
		protected WebElement grade;
		@FindBy(xpath = ".//form/div/div[3]/span")
		protected List<WebElement> gradefilter2;
		
		@FindBy(xpath = "//*[@id='taballocationlist']/..//td[6]")
		protected List<WebElement> expirydate;
		
		@FindBy(xpath = "//*[@id='content']/div[5]//td[5]")
		protected List<WebElement> userrole;
		
	/*	@FindBy(xpath = "//*[@id='taballocationlist']/tbody/tr/td[3]")
		protected List<WebElement> sortordernumber;
		*/
		@FindBy(xpath = "//*[@id='allocationAddToBasketForm']/div/div[2]")
		protected List<WebElement> gradefilter;
		
		@FindBy(xpath = "//*[@id='mngeLicences']/div[3]/div/div[1]/table/tbody/tr/td[2]")
		protected List<WebElement> gradefilter1;
		
		@FindBy(xpath = "//div[@id='content']//tr/td[4]")
		protected List<WebElement> Quantityallocatedsort;
		
		@FindBy(xpath = "//*[@id='taballocationlist']/tbody//td[6]")
		protected List<WebElement> Licsort;
		
		@FindBy(xpath = "//div[@id='content']//tr/td[4]")
		protected List<WebElement> Remaininglicences;
		
		@FindBy(xpath = "//tr[@class='prod-detail-head-tr']/td[5]")
		protected List<WebElement> totallicences1;
		
		@FindBy(xpath = "//*[@id='content']/div[5]//td[6]")
		protected List<WebElement> statuslist;
		
		@FindBy(linkText = "Status")
		protected WebElement Status;
		
		@FindBy(xpath = "//div[@id='content']/div[5]/div[6]")
		protected WebElement bundletable;
		
		@FindBy(xpath = "//*[@id='bndleSuccess']/h5")
		protected WebElement bundlecodeconf;
		
		    public Login(){
			this.driver = driver;
			PageFactory.initElements(driver, this);
			}   
		    
		    public void recallBundle(final String bundleName) {
		        WebElement bundleToSelect = driver.findElement(By.xpath("//*[@class='bundlecontent']//*[contains(text(),'"+bundleName+"')]/../..//*[@class='recall-confirm']"));
		        bundleToSelect.click();
		    }
		    
	        public void DAlogin() throws InterruptedException{
	    	username.sendKeys(usernametxt);
	    	Password.sendKeys(pwdtxt);
	    	Loginbutton.click();
	    	Schoolselect.click();
	    	String schoolValue = "123499999";
	    	WebElement element1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(@value,'"+schoolValue+"')]")));
	    	element1.click();    	
	    	WebElement element = wait.until(ExpectedConditions.elementToBeClickable((Loginbutton)));
	    	element.click();
	    	//Assert.assertTrue(homeverify.getText().contains("District Administrator, ZZ HMH QA Texas School 55, 2801 GATTIS"), "Homepage not loaded successfully");
	    	    }
	        
	        public void Multiuserlogin() throws InterruptedException{
		    	username.sendKeys(mulusernametxt);
		    	Password.sendKeys(mulpwdtxt);
		    	Loginbutton.click();
		    	Schoolselect.click();
		    	String schoolValue = "12756";
		    	WebElement element1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(@value,'"+schoolValue+"')]")));
		    	element1.click();    	
		    	WebElement element = wait.until(ExpectedConditions.elementToBeClickable((Loginbutton)));
		    	element.click();
		    	System.out.println(homeverify.getText());
		    	Assert.assertTrue(homeverify.getText().contains("District Administrator, ZZ HMH QA Texas School 55, 2801 GATTIS"), "Homepage not loaded successfully");
		    	changeorg.click();
		    	orgform.findElement(By.id("init_org")).click();
                WebElement element2 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(@value,'100018')]")));
		    	element2.click();
		    	element.click();
		    	wait.until(ExpectedConditions.alertIsPresent());
			    driver.switchTo().alert().accept();
			    Assert.assertTrue(homeverify.getText().contains("School Administrator, East Divide Eclc, PO Box 7321, Bismarck"), "Homepage not loaded successfully");
		    	
		    	    }
	        
	        public void SAlogin() throws InterruptedException{
	    	username.sendKeys(sauname);
	    	Password.sendKeys(sapwdtxt);
	    	Loginbutton.click();
	    	Schoolselect.click();
	    	String schoolValue = "123456";
	    	WebElement element1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(@value,'"+schoolValue+"')]")));
	    	element1.click();    	
	    	WebElement element = wait.until(ExpectedConditions.elementToBeClickable((Loginbutton)));
	    	element.click();
	    	//Assert.assertTrue(homeverify.getText().contains("District Administrator, ZZ HMH QA Texas School 55, 2801 GATTIS"), "Homepage not loaded successfully");
	    }
	        public void teacherlogin() throws InterruptedException{
	    	username.sendKeys(tcuname);
	    	Password.sendKeys(tcpwdtxt);
	    	Loginbutton.click();
	    	Licensesavailable.isDisplayed();
	    	Activebundles.isDisplayed();
	    	
	    	    	
	    	 }    	
	        public void DAFilter() throws InterruptedException{
	    	Actions builder = new Actions(driver);
	    	WebElement element = PRODUCTSANDLICENSES;
	    	builder.moveToElement(element).moveToElement(eTextbooks).click().build().perform();
	    	wait.until(ExpectedConditions.elementToBeClickable((gradeselect)));
	    	new Select(gradeselect).selectByVisibleText("8");
	    	new Select(statusselect).selectByVisibleText("Expired");
	    	new Select(licences).selectByVisibleText("All");
	    	for(WebElement compare:expirydate ){
	    	compare.getText().toString().contains("2014");
			}
	    	}
	    	
	    	 public void Homepageverify() throws InterruptedException{
	 	    	Actions builder = new Actions(driver);
	 	    	WebElement element = PRODUCTSANDLICENSES;
	 	    	builder.moveToElement(element).build().perform();
	 	    	assertTrue("eTextbooks is not displayed", dashboardverify.getText().contains("eTextbooks"));
	 	    	assertTrue("Teacher Resources is not displayed", dashboardverify.getText().contains("Teacher Resources"));
	 	    	assertTrue("Admin Resources is not displayed", dashboardverify.getText().contains("Admin Resources"));
	 	    	assertTrue("Allocate Licenses is not displayed", dashboardverify.getText().contains("Allocate Licenses"));
	 	    	assertTrue("Manage Licenses is not displayed", dashboardverify.getText().contains("Manage Licenses"));
	 	    	assertTrue("Allocation History is not displayed", dashboardverify.getText().contains("Allocation History"));
	    	
	    	 }
	    	 
	        public void DAorderSorting() throws InterruptedException{
	    	Actions builder = new Actions(driver);
	    	WebElement element = PRODUCTSANDLICENSES;
	    	builder.moveToElement(element).moveToElement(eTextbooks).click().build().perform();
	    	wait.until(ExpectedConditions.elementToBeClickable((gradeselect)));
	    	driver.findElement(By.linkText("Order number")).click();
	    	Thread.sleep(5000);
	    	ordersorting();	 
	        }
	        public void DAlicenceSorting() throws InterruptedException{
	    	Actions builder = new Actions(driver);
	    	WebElement element = PRODUCTSANDLICENSES;
	    	builder.moveToElement(element).moveToElement(eTextbooks).click().build().perform();
	    	wait.until(ExpectedConditions.elementToBeClickable((gradeselect)));
	    	driver.findElement(By.linkText("Total licenses")).click();
	    	Thread.sleep(5000);
	    	licencesorting();	 
	    }
		    private void ordersorting() {
			List<String> myList = new ArrayList<String>();
			List<String> newList = new ArrayList<String>();
			double orderNumber=999999999;
			List<WebElement> sortordernumber=driver.findElements(By.xpath("//*[@id='taballocationlist']/tbody/tr/td[2]"));
			for(WebElement sort1:sortordernumber ){
				myList.add(sort1.getText().toString());
				newList.add(sort1.getText().toString());
			}		
			System.out.println(newList);
			Collections.sort(myList);
			System.out.println(myList);
			boolean status=myList.equals(newList);
		}
	        private void licencesorting() {
			WebElement maxlicense = driver.findElement(By.xpath("//*[@id='taballocationlist']/tbody/tr[2]/td[7]"));
			Integer result = Integer.valueOf(maxlicense.getText());
			System.out.println(result);
			boolean isLastButtonDisplayed = Lastpage.isDisplayed();
			if(isLastButtonDisplayed)
			{
			Lastpage.click();
			wait.until(ExpectedConditions.elementToBeClickable((firstPage)));
			}
			List<WebElement> noOfRows = driver.findElements(By.xpath("//tbody/tr/td[@class='prod-arrow-right']"));
			int i=noOfRows.size();
			System.out.println("Size:" +i);
			WebElement minlicence = driver.findElement(By.xpath("//tbody/tr["+((i*3)-1)+"]/td[7]"));
			Integer result1 = Integer.valueOf(minlicence.getText());
			System.out.println(result1);
			boolean com = result > result1;
			System.out.println(com);
			assertTrue(com);	  	
	        }
	        public void DAAllocateLicences() throws InterruptedException{
	    	Actions builder = new Actions(driver);
	    	WebElement element = PRODUCTSANDLICENSES;
	    	builder.moveToElement(element).moveToElement(ALLOCATELICENSES).click().build().perform();
	    	wait.until(ExpectedConditions.elementToBeClickable((gradeselect)));
	    	new Select(gradeselect).selectByVisibleText("8");
	    	grade.click();
	    	Thread.sleep(5000);
	    	grade.click();
	    	Thread.sleep(5000);
	    	for (WebElement rowgrade: gradefilter)
	    	{
	    	if (rowgrade.getText().contains("8"))
	    	{
	    	
	    	}
	    	else{
	    	Assert.assertTrue(rowgrade.getText().contains("8")," grade filter not working");
	    	}
	        }
	    	
	    	}
	    
	        public void DAManageLicences() throws InterruptedException{
	        	Actions builder = new Actions(driver);
	        	WebElement element = PRODUCTSANDLICENSES;
	        	builder.moveToElement(element).moveToElement(MANAGELICENSES).click().build().perform();
	        	wait.until(ExpectedConditions.elementToBeClickable((gradeselect)));
	        	new Select(gradeselect).selectByVisibleText("8");
	        	grade.click();
	        	Thread.sleep(5000);
	        	grade.click();
	        	Thread.sleep(5000);
	        	for (WebElement rowgrade: gradefilter1)
	        	{
	        	System.out.println(rowgrade.getText());
	        	if (rowgrade.getText().contains("8"))
	        	{       		
	        	}
	        	else{
	        	Assert.assertTrue(rowgrade.getText().contains("8")," grade filter not working");
	        	}
	            }
	        	}
	        
	        public void DAAllocationHistory() throws InterruptedException{
	        	Actions builder = new Actions(driver);
	        	WebElement element = PRODUCTSANDLICENSES;
	        	builder.moveToElement(element).moveToElement(AllocationHistory).click().build().perform();
	        	wait.until(ExpectedConditions.elementToBeClickable((gradeselect)));
	        	new Select(gradeselect).selectByVisibleText("8");
	        	Quantityallocated.click();
	        	Thread.sleep(5000);
	        	Quantityallocated.click();
	        	Thread.sleep(5000);
	        	assertTrue(qaunsorting());
	        }
	        
	        private boolean qaunsorting() {
	    		List<Integer> myList = new ArrayList<Integer>();
	    		List<Integer> newList = new ArrayList<Integer>();
	    		List<WebElement> sortordernumber=Quantityallocatedsort;	
	    		for(WebElement sort1:sortordernumber ){
	    		int orderNumber=Integer.parseInt(sort1.getText());
	    		myList.add(orderNumber);
	    		newList.add(orderNumber);
	    		}		
	    		System.out.println(newList);
	    		Collections.sort(myList);
	    		System.out.println(myList);
	    		boolean status=myList.equals(newList);
	    		return status;
	    	}
	        public void DAusercreation() throws InterruptedException
	        {
	        	 Actions builder = new Actions(driver);
	        	 WebElement element = SCHOOLSANDUSERS;
	        	 builder.moveToElement(element).moveToElement(CreateUsers).click().build().perform();
	        	 wait.until(ExpectedConditions.elementToBeClickable((createuser)));
	        	 new Select(role).selectByVisibleText("District Administrator");
	        	 new Select(title).selectByVisibleText("Mr");
	             firstname.clear();
	        	 firstname.sendKeys(ufirstname);
	        	 lastname.clear();
	        	 lastname.sendKeys(ulastname);
	        	 email.clear();
	        	 email.sendKeys(mailid);
	        	 System.out.println(mailid);
	        	 pwd.clear();
	        	 pwd.sendKeys(password);
	        	 cnfpwd.clear();
	        	 cnfpwd.sendKeys(password);
	        	 createuser.click();
	        	 wait.until(ExpectedConditions.elementToBeClickable((createuser)));
	        	 assertTrue("created user name is not displayed", verifycreateduser.getText().contains(ufirstname));
	        	 
	        }
	        
	        public void SAusercreation() throws InterruptedException
	        {
	        	 Actions builder = new Actions(driver);
	        	 WebElement element = SCHOOLSANDUSERS;
	        	 builder.moveToElement(element).moveToElement(CreateUsers).click().build().perform();
	        	 wait.until(ExpectedConditions.elementToBeClickable((createuser)));
	        	 new Select(role).selectByVisibleText("School Administrator");
	        	 schooldrpdwn.click();
	        	 schoolselect1.click();
	        	 new Select(title).selectByVisibleText("Mr");
	             firstname.clear();
	        	 firstname.sendKeys(ufirstname);
	        	 lastname.clear();
	        	 lastname.sendKeys(ulastname);
	        	 email.clear();
	        	 email.sendKeys(mailid);
	        	 System.out.println(mailid);
	        	 pwd.clear();
	        	 pwd.sendKeys(password);
	        	 cnfpwd.clear();
	        	 cnfpwd.sendKeys(password);
	        	 createuser.click();
	        	 wait.until(ExpectedConditions.elementToBeClickable((createuser)));
	        	 assertTrue("created user name is not displayed", verifycreateduser.getText().contains(ufirstname));
	        	 
	        }
	        public void tcusercreation() throws InterruptedException
		        {
		        	 Actions builder = new Actions(driver);
		        	 WebElement element = SCHOOLSANDUSERS;
		        	 builder.moveToElement(element).moveToElement(CreateUsers).click().build().perform();
		        	 wait.until(ExpectedConditions.elementToBeClickable((createuser)));
		        	 new Select(role).selectByVisibleText("Teacher");
		        	 schooldrpdwn.click();
		        	 schoolselect1.click();
		        	 new Select(title).selectByVisibleText("Mr");
		             firstname.clear();
		        	 firstname.sendKeys(ufirstname);
		        	 lastname.clear();
		        	 lastname.sendKeys(ulastname);
		        	 email.clear();
		        	 email.sendKeys(mailid);
		        	 System.out.println("tc username:"+mailid);
		        	 pwd.clear();
		        	 pwd.sendKeys(password);
		        	 cnfpwd.clear();
		        	 cnfpwd.sendKeys(password);
		        	 createuser.click();
		        	 wait.until(ExpectedConditions.elementToBeClickable((createuser)));
		        	 assertTrue("created user name is not displayed", verifycreateduser.getText().contains(ufirstname));
		        	 }
		        public void DAteacherresource() throws InterruptedException{
		        	Actions builder = new Actions(driver);
		        	WebElement element = PRODUCTSANDLICENSES;
		        	builder.moveToElement(element).moveToElement(TeacherResources).click().build().perform();
		        	wait.until(ExpectedConditions.elementToBeClickable((gradeselect)));
		        	new Select(gradeselect).selectByVisibleText("8");
		        	Totallicences.click();
		        	driver.navigate().refresh();
		        	Totallicences.click();
		        	Thread.sleep(10000);
		        	wait.until(ExpectedConditions.elementToBeClickable((Lastpage)));
		        	waitForLoad(driver);
		        	assertTrue(qaunsorting1());
		             }		
		     public void DAuserfilter() throws InterruptedException{
		        	Actions builder = new Actions(driver);
		        	WebElement element = SCHOOLSANDUSERS;
		        	builder.moveToElement(element).moveToElement(Manageusers).click().build().perform();
		        	wait.until(ExpectedConditions.elementToBeClickable((Lastpage)));
		        	new Select(userselect).selectByVisibleText("District Administrators");
		        	for(WebElement compare:userrole ){
		    	    compare.getText().toString().equals("DA");
		    		}
		        	new Select(userselect).selectByVisibleText("All");
		        	Status.click();
		        	Thread.sleep(10000);
		        	Status.click();
		        	Thread.sleep(10000);
		        	usersorting();
		            }		
		        
		        
	        private boolean qaunsorting1() {
	    		List<Integer> myList = new ArrayList<Integer>();
	    		List<Integer> newList = new ArrayList<Integer>();
	    		List<WebElement> sortordernumber=totallicences1;
	    		for(WebElement sort1:sortordernumber ){
	    			System.out.println("Print:" + sort1.getText());
	    		int orderNumber=Integer.parseInt(sort1.getText().trim());
	    		myList.add(orderNumber);
	    		newList.add(orderNumber);
	    		}		
	    		System.out.println(newList);
	    		Collections.sort(myList);
	    		System.out.println(myList);
	    		boolean status=myList.equals(newList);
	    		return status;
	    	}
		        
	        private boolean usersorting() {
	        	List<String> myList = new ArrayList<String>();
				List<String> newList = new ArrayList<String>();
	    		List<WebElement> sortordernumber=statuslist;
	    		for(WebElement sort1:sortordernumber ){
	    			System.out.println("Print:" + sort1.getText());
	    		myList.add(sort1.getText());
	    		newList.add(sort1.getText());
	    		}		
	    		System.out.println(newList);
	    		Collections.sort(myList);
	    		System.out.println(myList);
	    		boolean status=myList.equals(newList);
	    		return status;
	    	}
			    public void waitForLoad(WebDriver driver) {
			            ExpectedCondition<Boolean> pageLoadCondition = new
			                    ExpectedCondition<Boolean>() {
			                        public Boolean apply(WebDriver driver) {
			                            return ((JavascriptExecutor)driver).executeScript("return document.readyState").equals("complete");
			                        }
			                    };
			            WebDriverWait wait = new WebDriverWait(driver, 30);
			            wait.until(pageLoadCondition);
			        }
	
			   
			    public void testPackage() throws Exception {
			      Actions builder = new Actions(driver);
		          WebElement element = Pakages;
		          builder.moveToElement(element).moveToElement(CreatePackages).click().build().perform();
		          wait.until(ExpectedConditions.elementToBeClickable((gradeselect)));
			      driver.findElement(By.cssSelector("input.createPackageAdd")).click();
			      driver.findElement(By.cssSelector("input.createPackageAdd")).click();
			      driver.findElement(By.id("createPackageBtn")).click();
			      driver.findElement(By.id("name")).clear();
			      driver.findElement(By.id("name")).sendKeys(ufirstname);
			      driver.findElement(By.id("subject")).clear();
			      driver.findElement(By.id("subject")).sendKeys(ufirstname);
			      driver.findElement(By.id("grade")).clear();
			      driver.findElement(By.id("grade")).sendKeys("5");
			      driver.findElement(By.id("quantity")).clear();
			      driver.findElement(By.id("quantity")).sendKeys("1");
			      driver.findElement(By.id("createPackageBtn")).click();
			      driver.findElement(By.cssSelector("a.finalize")).click();			      
			      driver.findElement(By.cssSelector("a.finalize")).click();
			      wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.cssSelector("a.finalize-confirm"))));
			      driver.findElement(By.cssSelector("a.finalize-confirm")).click();
			      wait.until(ExpectedConditions.alertIsPresent());
			      driver.switchTo().alert().accept();
			      //assertEquals(closeAlertAndGetItsText(), "Package Status is changed. Hence, refreshing the page");
			      //wait.until(ExpectedConditions.urlContains("https://dc-cert.hmhco.com/hmhstorefront/packages/completePackage?bundleCode="));
			      
			    } 
			    private String closeAlertAndGetItsText() {
			        try {
			          Alert alert = driver.switchTo().alert();
			          String alertText = alert.getText();
			          if (acceptNextAlert) {
			            alert.accept();
			          } else {
			            alert.dismiss();
			          }
			          return alertText;
			        } finally {
			          acceptNextAlert = true;
			        }
	   			    }
			    
			    public void searchfunc() throws InterruptedException
		        {
		        	 Actions builder = new Actions(driver);
		        	 WebElement element = PRODUCTSANDLICENSES;
		        	 builder.moveToElement(element).moveToElement(eTextbooks).click().build().perform();
		        	 wait.until(ExpectedConditions.elementToBeClickable((gradeselect)));
		        	 search.sendKeys("propaganda");
		        	 searchbutton.click();
		        	 wait.until(ExpectedConditions.elementToBeClickable((gradeselect)));
		        	 assertTrue("search functionality is not working", searchtable.getText().contains("Propaganda"));
		             System.out.println(searchtable.getText());
		        }
			    
			    public void tcheTextbooks() throws InterruptedException
		        {
			    	dashboard.click();
			    	Licensesavailable.click();
			    	bundleproduct1.isDisplayed();
			    	createbundlecontinue.isDisplayed();
			    	dashboard.click();
			    	Activebundles.click();
			    	waitForLoad(driver);
			    	filterSearchByStatus.isDisplayed();
		        	Actions builder = new Actions(driver);
		        	WebElement element = PRODUCTSANDLICENSES;
		        	builder.moveToElement(element).moveToElement(eTextbooks).click().build().perform();
		        	wait.until(ExpectedConditions.elementToBeClickable((gradeselect)));
		        	licsorting();
		        }
		        	 private boolean licsorting() {
		 	    		List<Integer> myList = new ArrayList<Integer>();
		 	    		List<Integer> newList = new ArrayList<Integer>();
		 	    		List<WebElement> sortordernumber=Licsort;
		 	    		for(WebElement sort1:sortordernumber ){
		 	    		int orderNumber=Integer.parseInt(sort1.getText());
		 	    		myList.add(orderNumber);
		 	    		newList.add(orderNumber);
		 	    		}		
		 	    		System.out.println(newList);
		 	    		Collections.sort(myList);
		 	    		System.out.println(myList);
		 	    		boolean status=myList.equals(newList);
		 	    		return status;
		 	    	}
		        	 
	  
			    public void testbundle() throws Exception {
			    	 Actions builder = new Actions(driver);
		        	 WebElement element = BUNDLES;
		        	 builder.moveToElement(element).moveToElement(createbundle).click().build().perform();
			         wait.until(ExpectedConditions.elementToBeClickable((gradeselect)));
			         new Select(gradeselect).selectByVisibleText("8");
			         for(WebElement grades:gradefilter2)
			         {
			        	 boolean found=false;
			        	 for(int i=8;i<=12;i++)
			        	 {
			        	 if(grades.getText().contains("-"+i))
			        	 {
			        		 found=true; 
			        		 System.out.println(grades.getText());
			        		 break;
			        	 }
			        	 else if(grades.getText().contains("8"))
			        	 {
			        		 System.out.println(grades.getText());
			        		 found=true; 
			        		 break;
			        	 }
			        		
			        	 }			        	
			        	assertTrue("Grade Filtering functionality is not working", found);			        	 
			         }			        		         
			         bundleproduct1.click();
			         bundleproduct1.click();
			         bundleproduct2.click();
			         bundleproduct1.click();			        
			         createbundlecontinue.click();
			         driver.findElement(By.id("name")).clear();
				     driver.findElement(By.id("name")).sendKeys(ufirstname);
				     System.out.println(ufirstname);
				     driver.findElement(By.id("subject")).clear();
				     driver.findElement(By.id("subject")).sendKeys(ufirstname);
				     driver.findElement(By.id("grade")).clear();
				     driver.findElement(By.id("grade")).sendKeys("5");
				     driver.findElement(By.id("quantity")).clear();
				     driver.findElement(By.id("quantity")).sendKeys("1");
				     Loginbutton.click();
				     System.out.println(bundlesuccess.getText());
				     Assert.assertTrue(bundlesuccess.getText().contains("Your bundle has been created."), "bundle creation is not working");
				     bundlerecall();
				     bundlereissue();
			    } 
			    
			    private void bundlerecall() throws Exception {
			    	 Actions builder = new Actions(driver);
		        	 WebElement element = BUNDLES;
		        	 builder.moveToElement(element).moveToElement(Managebundles).click().build().perform();
		        	 driver.findElement(By.xpath("//*[contains(text(),'"+ufirstname+"')]/../../div[9]//a[@class='recall']")).click();
		        	 wait.until(ExpectedConditions.elementToBeClickable((recallconfirm)));
		        	 recallBundle(ufirstname);
		        	 assertFalse("bundle not recalled", bundletable.getText().equals(ufirstname));
				    } 
			    private void bundlereissue() throws Exception {			    	
			    	 Actions builder = new Actions(driver);
		        	 WebElement element = BUNDLES;
		        	 builder.moveToElement(element).moveToElement(Managebundles).click().build().perform();
		        	 new Select(bundlestatus).selectByVisibleText("Recalled");
		        	 driver.findElement(By.xpath("//*[contains(text(),'"+ufirstname+"')]/../../div[9]//a[@class='reissue']")).click();
		        	 driver.findElement(By.id("name")).clear();
				     driver.findElement(By.id("name")).sendKeys(ulastname);
				     driver.findElement(By.id("quantity")).clear();
				     driver.findElement(By.id("quantity")).sendKeys("1");
		        	 wait.until(ExpectedConditions.elementToBeClickable((reissueconfirm)));
		        	 reissueconfirm.click();
		        	 System.out.println(bundlesuccess.getText());
		        	 assertTrue("bundle not reissued", bundlecodeconf.getText().contains("New Bundle code:"));
		        	 Actions builder1 = new Actions(driver);
		        	 WebElement element1 = BUNDLES;
		        	 builder1.moveToElement(element1).moveToElement(Managebundles).click().build().perform();
		        	 assertTrue("bundle is not visible in manage bundles page", driver.findElement(By.xpath("//*[contains(text(),'"+ulastname+"')]")).getText().contains(ulastname));
				    } 
	
			    public void Managepackages() throws Exception {
			    	 Actions builder = new Actions(driver);
		        	 WebElement element = Pakages;
		        	 builder.moveToElement(element).moveToElement(Managepackages).click().build().perform();
		        	 wait.until(ExpectedConditions.elementToBeClickable((Lastpage)));
		        	 status.click();
					 wait.until(ExpectedConditions.elementToBeClickable((Lastpage)));
					 Thread.sleep(5000);
					 datesorting();
			    }
					 private void datesorting() throws Exception {
							List<String> myList = new ArrayList<String>();
							List<String> newList = new ArrayList<String>();
							List<WebElement> sortordernumber=driver.findElements(By.xpath("//*[@class='bundlerow pkg']//div[1]"));
							for(WebElement sort1:sortordernumber ){
								System.out.println(sort1.getText());
								myList.add(sort1.getText());
								newList.add(sort1.getText());
							}		
							System.out.println(newList);
							Collections.sort(myList);
							System.out.println(myList);
							boolean status=myList.equals(newList);
						}
			       
					 public void Logout() throws Exception {
						 driver.findElement(By.linkText("Log Out")).click();
						 assertTrue("Login page not displayed", forgotpassword.getText().equals("Forgotten your password?"));
						 assertTrue("Login page not displayed", studentlink.getText().equals("I am a Student"));
						 
				    }
					 
					 public void studentverify() throws Exception {
						
						 studentlink.click();
						 System.out.println(downloadpage.getText());
						 assertTrue("Ipad download link not displayed", downloadpage.getText().contains("iPad"));
															 
				    }
			    
					 
	}
			
