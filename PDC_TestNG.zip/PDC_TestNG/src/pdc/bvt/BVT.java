package pdc.bvt;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import pdc.*;
import java.util.Set;
import junit.framework.TestCase;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import base.BaseTest;
import com.thoughtworks.selenium.Selenium;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import pdc.pages.Login;
import com.google.common.base.Predicate;
	    public class BVT extends BaseTest{
     	@Test
		 public void pdc_test_01() throws InterruptedException
			 {	
			new Login().DAlogin();
			 }
		@Test
		 public void pdc_test_02() throws InterruptedException
			 {

			new Login().SAlogin();
			 }
		@Test
		 public void pdc_test_03() throws InterruptedException
			 {

			new Login().teacherlogin();
			 }	
		@Test
		 public void pdc_test_04() throws InterruptedException
			 {
			 new Login().DAlogin();
			 new Login().DAusercreation();
			}
		
		@Test
		 public void pdc_test_05() throws InterruptedException
			 {
			 new Login().DAlogin();
			 new Login().SAusercreation();
			}
		 		
		@Test
		 public void pdc_test_06() throws InterruptedException
			 {
			 new Login().DAlogin();
			 new Login().tcusercreation();
			}
		
		@Test
		 public void pdc_test_07_08() throws InterruptedException
			 {
			   new Login().DAlogin();
			   new Login().DAFilter();
			   new Login().DAorderSorting();
			 } 
		@Test
		//review
		 public void pdc_test_DAlicenceSorting() throws InterruptedException
			 {
			    new Login().DAlogin();
				new Login().DAorderSorting();
				new Login().DAlicenceSorting();
			 }	 
		
		@Test
		 public void pdc_test_09_10() throws InterruptedException
			 {
			    new Login().DAlogin();
			    new Login().DAAllocateLicences();
			  }	 
		 @Test
		 public void pdc_test_11_12() throws InterruptedException
			 {
			    new Login().DAlogin();
				new Login().DAManageLicences();
			 }	  	 
		 @Test
		 public void pdc_test_13_14() throws InterruptedException
			 {
			 new Login().DAlogin();
			 new Login().DAAllocationHistory();
			}	
	
		@Test
		 public void pdc_test_15_16() throws InterruptedException
			 {
			 new Login().DAlogin();
			 new Login().DAteacherresource();
			}
		 	
		@Test
		 public void pdc_test_17() throws Exception
			 {
			 new Login().teacherlogin();
			 new Login().testbundle();
			}
		
		@Test
		 public void pdc_test_18() throws Exception
			 {
			 new Login().teacherlogin();
			 new Login().Logout();
			}
		
		@Test
		 public void pdc_test_19() throws InterruptedException
			 {
			 new Login().DAlogin();
			 new Login().DAuserfilter();
			}
		 
		@Test
		 public void pdc_test_20() throws Exception
			 {
			 new Login().teacherlogin();
			 new Login().searchfunc();
			} 
		
		@Test
		 public void pdc_test_21_22() throws Exception
			 {
			 new Login().teacherlogin();
			 new Login().tcheTextbooks();
			 } 
		
		@Test
		 public void pdc_test_23() throws Exception
			 {
			 new Login().Multiuserlogin();
						}
		@Test
		 public void pdc_test_24() throws Exception
			 {
			 new Login().DAlogin();
			 new Login().testPackage();
			}
		@Test
		 public void pdc_test_26() throws Exception
			 {
			 new Login().teacherlogin();
			 new Login().testbundle();
			}
		 
		@Test
		 public void pdc_test_29() throws Exception
			 {
			 new Login().SAlogin();
			 new Login().Homepageverify();
			}
		
		@Test
		 public void pdc_test_30() throws Exception
			 {
			
			 new Login().studentverify();
			 driver.navigate().back();
			 new Login().teacherlogin();
			}
						
		@Test
		 public void pdc_test_31() throws Exception
			 {
			 new Login().SAlogin();
			 new Login().Managepackages();
			}
		
}
